package com.shinku.reader.ui.browse.feed

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.FilterList
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import cafe.adriel.voyager.core.model.rememberScreenModel
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.core.stack.StackEvent
import cafe.adriel.voyager.navigator.LocalNavigator
import cafe.adriel.voyager.navigator.currentOrThrow
import com.shinku.reader.presentation.browse.FeedScreen
import com.shinku.reader.presentation.browse.components.FeedAddDialog
import com.shinku.reader.presentation.browse.components.FeedAddSearchDialog
import com.shinku.reader.presentation.browse.components.FeedDeleteConfirmDialog
import com.shinku.reader.presentation.browse.components.FeedFilterDialog
import com.shinku.reader.presentation.components.AppBar
import com.shinku.reader.presentation.components.TabContent
import com.shinku.reader.ui.browse.source.browse.BrowseSourceScreen
import com.shinku.reader.ui.browse.source.globalsearch.GlobalSearchScreen
import com.shinku.reader.ui.manga.MangaScreen
import kotlinx.collections.immutable.persistentListOf
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import com.shinku.reader.domain.source.interactor.GetRemoteManga
import com.shinku.reader.i18n.MR
import com.shinku.reader.i18n.sy.SYMR
import com.shinku.reader.presentation.core.i18n.stringResource

@Composable
fun Screen.feedTab(): TabContent {
    val navigator = LocalNavigator.currentOrThrow
    val screenModel = rememberScreenModel { FeedScreenModel() }
    val state by screenModel.state.collectAsState()

    DisposableEffect(navigator.lastEvent) {
        if (navigator.lastEvent == StackEvent.Push) {
            screenModel.pushed = true
        } else if (!screenModel.pushed) {
            screenModel.init(force = false)
        }

        onDispose {
            if (navigator.lastEvent == StackEvent.Idle && screenModel.pushed) {
                screenModel.pushed = false
            }
        }
    }

    return TabContent(
        titleRes = SYMR.strings.feed,
        actions = persistentListOf(
            AppBar.Action(
                title = stringResource(MR.strings.action_add),
                icon = Icons.Outlined.Add,
                onClick = {
                    screenModel.openAddDialog()
                },
            ),
            AppBar.Action(
                title = stringResource(MR.strings.action_filter),
                icon = Icons.Outlined.FilterList,
                onClick = {
                    screenModel.openFilterDialog()
                },
            ),
        ),
        content = { contentPadding, snackbarHostState ->
            FeedScreen(
                state = state,
                contentPadding = contentPadding,
                onClickSavedSearch = { savedSearch, source ->
                    screenModel.sourcePreferences.lastUsedSource().set(savedSearch.source)
                    navigator.push(
                        BrowseSourceScreen(
                            source.id,
                            listingQuery = null,
                            savedSearch = savedSearch.id,
                        ),
                    )
                },
                onClickSource = { source ->
                    screenModel.sourcePreferences.lastUsedSource().set(source.id)
                    navigator.push(
                        BrowseSourceScreen(
                            source.id,
                            GetRemoteManga.QUERY_LATEST,
                        ),
                    )
                },
                onClickDelete = screenModel::openDeleteDialog,
                onClickManga = { manga ->
                    navigator.push(MangaScreen(manga.id, true))
                },
                onClickGenre = screenModel::selectGenre,
                onSeeAllGenre = { genre ->
                    navigator.push(GlobalSearchScreen(genre))
                },
                onSeeAllTitles = { title, mangas, mode, query ->
                    navigator.push(SuggestedTitlesScreen(title, mangas, mode, query))
                },
                onAddFeed = screenModel::openAddDialog,
                onRefresh = { screenModel.init(force = true) },
                getMangaState = { manga -> screenModel.getManga(initialManga = manga) },
            )

            state.dialog?.let { dialog ->
                when (dialog) {
                    is FeedScreenModel.Dialog.FeedFilter -> {
                        FeedFilterDialog(
                            currentSourceFilter = screenModel.shinkuPreferences.feedSourceFilter().get(),
                            currentLanguageFilter = screenModel.shinkuPreferences.feedLanguageFilter().get(),
                            currentShowSourceFeeds = screenModel.shinkuPreferences.feedShowSourceFeeds().get(),
                            customFeeds = state.items,
                            enabledLanguages = screenModel.sourcePreferences.enabledLanguages().get(),
                            onDismiss = screenModel::dismissDialog,
                            onApply = { sourceFilter, languageFilter, showSourceFeeds ->
                                screenModel.shinkuPreferences.feedSourceFilter().set(sourceFilter)
                                screenModel.shinkuPreferences.feedLanguageFilter().set(languageFilter)
                                screenModel.shinkuPreferences.feedShowSourceFeeds().set(showSourceFeeds)
                                screenModel.dismissDialog()
                                screenModel.init(force = true)
                            },
                            onAddFeed = {
                                screenModel.dismissDialog()
                                screenModel.openAddDialog()
                            },
                            onDeleteFeed = { feed ->
                                screenModel.openDeleteDialog(feed)
                            },
                        )
                    }
                    is FeedScreenModel.Dialog.AddFeed -> {
                        FeedAddDialog(
                            sources = dialog.options,
                            onDismiss = screenModel::dismissDialog,
                            onClickAdd = {
                                if (it != null) {
                                    screenModel.openAddSearchDialog(it)
                                }
                                screenModel.dismissDialog()
                            },
                        )
                    }
                    is FeedScreenModel.Dialog.AddFeedSearch -> {
                        FeedAddSearchDialog(
                            source = dialog.source,
                            savedSearches = dialog.options,
                            onDismiss = screenModel::dismissDialog,
                            onClickAdd = { source, savedSearch ->
                                screenModel.createFeed(source, savedSearch)
                                screenModel.dismissDialog()
                            },
                        )
                    }
                    is FeedScreenModel.Dialog.DeleteFeed -> {
                        FeedDeleteConfirmDialog(
                            feed = dialog.feed,
                            onDismiss = screenModel::dismissDialog,
                            onClickDeleteConfirm = {
                                screenModel.deleteFeed(it)
                                screenModel.dismissDialog()
                            },
                        )
                    }
                }
            }

            val internalErrString = stringResource(MR.strings.internal_error)
            val tooManyFeedsString = stringResource(SYMR.strings.too_many_in_feed)
            LaunchedEffect(Unit) {
                screenModel.events.collectLatest { event ->
                    when (event) {
                        FeedScreenModel.Event.FailedFetchingSources -> {
                            launch { snackbarHostState.showSnackbar(internalErrString) }
                        }
                        FeedScreenModel.Event.TooManyFeeds -> {
                            launch { snackbarHostState.showSnackbar(tooManyFeedsString) }
                        }
                    }
                }
            }
        },
    )
}
