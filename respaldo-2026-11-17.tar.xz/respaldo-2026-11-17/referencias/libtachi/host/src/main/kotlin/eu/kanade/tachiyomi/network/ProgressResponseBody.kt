// Ported from Mihon (Apache-2.0): core/common/src/main/kotlin/eu/kanade/tachiyomi/network/ProgressResponseBody.kt
package eu.kanade.tachiyomi.network

import okhttp3.MediaType
import okhttp3.ResponseBody
import okio.Buffer
import okio.BufferedSource
import okio.ForwardingSource
import okio.Source
import okio.buffer
import java.io.IOException

class ProgressResponseBody(
    private val responseBody: ResponseBody,
    private val progressListener: ProgressListener,
    private val existingSize: Long = 0L,
) : ResponseBody() {
    private val bufferedSource: BufferedSource by lazy { source(responseBody.source()).buffer() }

    override fun contentType(): MediaType? = responseBody.contentType()

    override fun contentLength(): Long = responseBody.contentLength()

    override fun source(): BufferedSource = bufferedSource

    private fun source(source: Source): Source {
        return object : ForwardingSource(source) {
            var totalBytesRead = existingSize

            @Throws(IOException::class)
            override fun read(sink: Buffer, byteCount: Long): Long {
                val bytesRead = super.read(sink, byteCount)
                totalBytesRead += if (bytesRead != -1L) bytesRead else 0
                val totalLength = responseBody.contentLength().let { if (it != -1L) it + existingSize else -1L }
                progressListener.update(totalBytesRead, totalLength, bytesRead == -1L)
                return bytesRead
            }
        }
    }
}
