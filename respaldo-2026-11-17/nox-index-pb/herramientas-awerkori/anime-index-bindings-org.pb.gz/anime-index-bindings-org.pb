
Project Nox Anime	Nox Anime@144f44e865cbfae6bde110489ef7ec142f0b1681f627a093a218650e21db5dad"-
+https://github.com/Awerkori/anime-extensoes���
�
Aniyomi: AnimeOnsen1eu.kanade.tachiyomi.animeextension.all.animeonsen�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.animeonsen-v14.11.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.animeonsen.png"14(˹U214.118B7՟������v
AnimeOnsenall"https://www.animeonsen.xyz
�
Aniyomi: AnimeWorld India6eu.kanade.tachiyomi.animeextension.all.animeworldindia�
jhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.animeworldindia-v14.30.apkyhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.animeworldindia.png"14(޹U214.308B9�Щ�����AnimeWorld Indiaall"https://anime-world.coB8�ԋ����AnimeWorld Indiabn"https://anime-world.coB8�̎�����oAnimeWorld Indiaen"https://anime-world.coB8�Ғ�����lAnimeWorld Indiahi"https://anime-world.coB8��䄫��� AnimeWorld Indiaja"https://anime-world.coB8������׬&AnimeWorld Indiaml"https://anime-world.coB8�������fAnimeWorld Indiamr"https://anime-world.coB8ӧ������|AnimeWorld Indiata"https://anime-world.coB8�������yAnimeWorld Indiate"https://anime-world.co
�
Aniyomi: AnimeXin/eu.kanade.tachiyomi.animeextension.all.animexin�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.animexin-v14.38.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.animexin.png"14(�U214.388B/��鎘���@AnimeXinall"https://animexin.dev
�
Aniyomi: AniZone.eu.kanade.tachiyomi.animeextension.all.anizone�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.anizone-v16.22.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.anizone.png"16(��a216.228B,���ᾓ�AniZoneall"https://anizone.to
�
Aniyomi: ChineseAnime3eu.kanade.tachiyomi.animeextension.all.chineseanime�
ghttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.chineseanime-v14.42.apkvhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.chineseanime.png"14(�U214.428B:�Ρ�����wChineseAnimeall"https://www.chineseanime.in
�
Aniyomi: Debrid Index2eu.kanade.tachiyomi.animeextension.all.debridindex�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.debridindex-v14.3.apkuhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.debridindex.png"14(ùU214.38B:�������Debrid Indexall"https://torrentio.strem.fun
�
Aniyomi: Google Drive2eu.kanade.tachiyomi.animeextension.all.googledrive�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.googledrive-v14.24.apkuhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.googledrive.png"14(عU214.248B7��ʨ����:Google Driveall"https://drive.google.com
�
Aniyomi: GoogleDriveIndex7eu.kanade.tachiyomi.animeextension.all.googledriveindex�
khttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.googledriveindex-v14.12.apkzhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.googledriveindex.png"14(̹U214.128B!���Ž��hGoogleDriveIndexall
�
!Aniyomi: Hentai Torrent (Torrent)4eu.kanade.tachiyomi.animeextension.all.hentaitorrent�
ghttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.hentaitorrent-v14.6.apkwhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.hentaitorrent.png"14(ƹU214.68BIӂ��޶��FHentai Torrent (Torrent)all"https://www.hentaitorrents.com
�
Aniyomi: Jable,eu.kanade.tachiyomi.animeextension.all.jable�
_https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.jable-v14.3.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.jable.png"14(ùU214.38B'��������DJablezh"https://jable.tvB'簭ޚ���Jableen"https://jable.tvB'�д�����eJableja"https://jable.tv
�
Aniyomi: JavGG,eu.kanade.tachiyomi.animeextension.all.javgg�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.javgg-v14.29.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.javgg.png"14(ݹU214.298B)�������.JavGGall"https://javgg.net
�
Aniyomi: Jav Guru.eu.kanade.tachiyomi.animeextension.all.javguru�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.javguru-v14.54.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.javguru.png"14(��U214.548B+��������vJav Guruall"https://jav.guru
�
Aniyomi: Jellyfin/eu.kanade.tachiyomi.animeextension.all.jellyfin�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.jellyfin-v16.33.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.jellyfin.png"16(��a216.338B�ރҪ���}Jellyfin (1)allB����˦��DJellyfin (2)allB������hJellyfin (3)all
�
Aniyomi: Kartoons/eu.kanade.tachiyomi.animeextension.all.kartoons�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.kartoons-v16.4.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.kartoons.png"16(��a216.48B.��Ƶ����oKartoonsall"https://kartoons.to
�
Aniyomi: LMAnime.eu.kanade.tachiyomi.animeextension.all.lmanime�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.lmanime-v14.36.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.lmanime.png"14(�U214.368B-���ګ�ؠeLMAnimeall"https://lmanime.com
�
Aniyomi: MissAV-eu.kanade.tachiyomi.animeextension.all.missav�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.missav-v14.43.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.missav.png"14(�U214.438B,̐ǫ㦓�MissAVall"https://missav.live
�
Aniyomi: Movy+eu.kanade.tachiyomi.animeextension.all.movy�
^https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.movy-v16.7.apknhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.movy.png"16(��a216.78B*��Ճ����{Movyall"https://www.movy.sx
�
Aniyomi: MyReadingManga5eu.kanade.tachiyomi.animeextension.all.myreadingmanga�
hhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.myreadingmanga-v14.3.apkxhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.myreadingmanga.png"14(ùU214.38B;ή놌���CMyReadingMangaar"https://myreadingmanga.infoB;屹�����zMyReadingMangaid"https://myreadingmanga.infoB;��ן����#MyReadingMangabg"https://myreadingmanga.infoB>����ƴӁzMyReadingMangazh-hk"https://myreadingmanga.infoB;���봚��sMyReadingMangazh"https://myreadingmanga.infoB>��ҿ���QMyReadingMangazh-tw"https://myreadingmanga.infoB;��������bMyReadingMangacs"https://myreadingmanga.infoB;���Τ���JMyReadingMangada"https://myreadingmanga.infoB;��ᛐ���WMyReadingMangaen"https://myreadingmanga.infoB<�����ܓ�,MyReadingMangafil"https://myreadingmanga.infoB;ɻ������MyReadingMangafi"https://myreadingmanga.infoB;��������<MyReadingManganl"https://myreadingmanga.infoB;���е���MyReadingMangafr"https://myreadingmanga.infoB;����ԥ�MyReadingMangade"https://myreadingmanga.infoB;�������zMyReadingMangael"https://myreadingmanga.infoB;��������HMyReadingMangahe"https://myreadingmanga.infoB;���ѵʴ�{MyReadingMangahi"https://myreadingmanga.infoB;�潂����xMyReadingMangahu"https://myreadingmanga.infoB;��������.MyReadingMangait"https://myreadingmanga.infoB;�ب�����iMyReadingMangaja"https://myreadingmanga.infoB;��ݪ����sMyReadingMangako"https://myreadingmanga.infoB;�ꬭ�ݐ�MyReadingMangams"https://myreadingmanga.infoB;���ˉ�uMyReadingMangano"https://myreadingmanga.infoB;��Ɣ�܃MyReadingMangapl"https://myreadingmanga.infoB>􄕆�ՠ�bMyReadingMangapt-BR"https://myreadingmanga.infoB;���޼��MyReadingMangaro"https://myreadingmanga.infoB;�����ռ:MyReadingMangaru"https://myreadingmanga.infoB;�筦Ќ��1MyReadingMangaes"https://myreadingmanga.infoB;Γ������CMyReadingMangasv"https://myreadingmanga.infoB;������MyReadingMangath"https://myreadingmanga.infoB;П�ݻ���MyReadingMangatr"https://myreadingmanga.infoB;�ؙ���9MyReadingMangavi"https://myreadingmanga.info
�
Aniyomi: Newgrounds1eu.kanade.tachiyomi.animeextension.all.newgrounds�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.newgrounds-v14.3.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.newgrounds.png"14(ùU214.38B7����̫
Newgroundsall"https://www.newgrounds.com
�
Aniyomi: Nyaa (Torrent)2eu.kanade.tachiyomi.animeextension.all.nyaatorrent�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.nyaatorrent-v14.11.apkuhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.nyaatorrent.png"14(˹U214.118B0����躺�INyaa (Torrent)all"https://nyaa.siBAѕ����~Nyaa Sukebein (Torrent)all"https://sukebei.nyaa.si
�
Aniyomi: PTorrent (Torrent)/eu.kanade.tachiyomi.animeextension.all.ptorrent�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.ptorrent-v14.6.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.ptorrent.png"14(ƹU214.68B>��������"PTorrent (Torrent)all"https://www.ptorrents.com
�
Aniyomi: RouVideo/eu.kanade.tachiyomi.animeextension.all.rouvideo�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.rouvideo-v14.21.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.rouvideo.png"14(չU214.218B2�ߘ�����e	肉視頻all"https://rou.video/homeB1�ǀ���ӄT	肉視頻zh"https://rou.video/homeB1����̾˲	肉視頻en"https://rou.video/homeB1�ϩ����q	肉視頻vi"https://rou.video/home
�
Aniyomi: StreamingCommunity9eu.kanade.tachiyomi.animeextension.all.streamingcommunity�
mhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.streamingcommunity-v14.32.apk|https://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.streamingcommunity.png"14(�U214.328BB���ȅ���	StreamingUnity (Movie)en"https://streamingunity.funBB�疓����StreamingUnity (Movie)it"https://streamingunity.funB?�����΍�StreamingUnity (Tv)en"https://streamingunity.funB?ļՌ�Ũ�dStreamingUnity (Tv)it"https://streamingunity.fun
�
Aniyomi: Stremio.eu.kanade.tachiyomi.animeextension.all.stremio�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.stremio-v16.18.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.stremio.png"16(��a216.188B9�����ݖ�tStremioall"https://app.strem.io/shell-v4.4
�
Aniyomi: Subsplease1eu.kanade.tachiyomi.animeextension.all.subsplease�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.subsplease-v14.9.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.subsplease.png"14(ɹU214.98B3��������y
Subspleaseall"https://subsplease.org
�
Aniyomi: SupJav-eu.kanade.tachiyomi.animeextension.all.supjav�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.supjav-v14.38.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.supjav.png"14(�U214.388B*��ԟ�։>SupJaven"https://supjav.comB*�߂��ʥ�+SupJavja"https://supjav.comB*���깗�%SupJavzh"https://supjav.com
�
Aniyomi: Torbox-eu.kanade.tachiyomi.animeextension.all.torbox�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.torbox-v14.2.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.torbox.png"14(¹U214.28B/�������xTorboxall"https://api.torbox.app
�
%Aniyomi: Torrentio (Torrent / Debrid)0eu.kanade.tachiyomi.animeextension.all.torrentio�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.torrentio-v16.13.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.torrentio.png"16(��a216.138BJ����ө��3Torrentio (Torrent / Debrid)all"https://torrentio.strem.fun
�
+Aniyomi: Torrentio Anime (Torrent / Debrid)5eu.kanade.tachiyomi.animeextension.all.torrentioanime�
ihttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.torrentioanime-v16.25.apkxhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.torrentioanime.png"16(��a216.258BP��̤���g"Torrentio Anime (Torrent / Debrid)all"https://torrentio.strem.fun
�
Aniyomi: Xnxx+eu.kanade.tachiyomi.animeextension.all.xnxx�
^https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.xnxx-v14.4.apknhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.xnxx.png"14(ĹU214.48B+�����Xnxxall"https://www.xnxx.com
�
Aniyomi: Xvideos.eu.kanade.tachiyomi.animeextension.all.xvideos�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.xvideos-v14.4.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.xvideos.png"14(ĹU214.48B1��̔��ȠoXvideosall"https://www.xvideos.com
�
Aniyomi: YFantasy/eu.kanade.tachiyomi.animeextension.all.yfantasy�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-all.yfantasy-v16.4.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.all.yfantasy.png"16(��a216.48B.��������YFantasyall"https://yfantasy.me
�
Aniyomi: Anime4up.eu.kanade.tachiyomi.animeextension.ar.anime4up�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ar.anime4up-v14.90.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ar.anime4up.png"14(��U214.908B2�������Anime4Upar"https://w1.anime4up.rest
�
Aniyomi: Anime Blkom0eu.kanade.tachiyomi.animeextension.ar.animeblkom�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ar.animeblkom-v14.40.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ar.animeblkom.png"14(�U214.408B=�ħ�Ǐ��Oأنمي بالكومar"https://animeblkom.net
�
Aniyomi: Animeiat.eu.kanade.tachiyomi.animeextension.ar.animeiat�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ar.animeiat-v14.2.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ar.animeiat.png"14(¹U214.28B4��Ť����bAnimeiatar"https://api.animeiat.co/v1
�
Aniyomi: AnimeLek.eu.kanade.tachiyomi.animeextension.ar.animelek�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ar.animelek-v14.47.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ar.animelek.png"14(�U214.478B-���槍Ț
AnimeLekar"https://animelek.me
�
Aniyomi: Animerco.eu.kanade.tachiyomi.animeextension.ar.animerco�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ar.animerco-v14.69.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ar.animerco.png"14(��U214.698B3��Զ���=Animercoar"https://zeta.animerco.org
�
Aniyomi: ArabAnime/eu.kanade.tachiyomi.animeextension.ar.arabanime�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ar.arabanime-v14.3.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ar.arabanime.png"14(ùU214.38B4ᆎ�����j	ArabAnimear"https://www.arabanime.net
�
Aniyomi: Arab Seed.eu.kanade.tachiyomi.animeextension.ar.arabseed�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ar.arabseed-v14.39.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ar.arabseed.png"14(�U214.398B2�Ë�𗸈?عرب سيدar"https://m.asd.homes
�
Aniyomi: asia2tv-eu.kanade.tachiyomi.animeextension.ar.asia2tv�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ar.asia2tv-v14.48.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ar.asia2tv.png"14(�U214.488B/��������Asia2TVar"https://ww1.asia2tv.pw
�
Aniyomi: Cimaleek.eu.kanade.tachiyomi.animeextension.ar.cimaleek�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ar.cimaleek-v14.18.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ar.cimaleek.png"14(ҹU214.188B6�������}سيما ليكar"https://m.cimaleek.to
�
Aniyomi: Egy Dead-eu.kanade.tachiyomi.animeextension.ar.egydead�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ar.egydead-v14.37.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ar.egydead.png"14(�U214.378B/��׍����tEgy Deadar"https://egydead.space
�
Aniyomi: FASELHD-eu.kanade.tachiyomi.animeextension.ar.faselhd�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ar.faselhd-v14.39.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ar.faselhd.png"14(�U214.398B?�������فاصل اعلانيar"https://www.faselhds.biz
�
Aniyomi: Okanime-eu.kanade.tachiyomi.animeextension.ar.okanime�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ar.okanime-v14.35.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ar.okanime.png"14(�U214.358B0�ɣ�����Okanimear"https://www.okanime.xyz
�
Aniyomi: Tuktuk Cinema2eu.kanade.tachiyomi.animeextension.ar.tuktukcinema�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ar.tuktukcinema-v14.20.apkuhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ar.tuktukcinema.png"14(ԹU214.208B>������fتوك توك سينماar"https://tuktukhd.com
�
Aniyomi: WIT ANIME.eu.kanade.tachiyomi.animeextension.ar.witanime�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ar.witanime-v14.71.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ar.witanime.png"14(��U214.718B0��Ъ�Ӫ�|	WIT ANIMEar"https://witanime.cyou
�
Aniyomi: FilmiFen.eu.kanade.tachiyomi.animeextension.bg.filmifen�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-bg.filmifen-v16.10.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.bg.filmifen.png"16(��a216.108B.٪������"FilmiFenbg"https://filmifen.com
�
Aniyomi: Anime-Base/eu.kanade.tachiyomi.animeextension.de.animebase�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-de.animebase-v14.56.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.de.animebase.png"14(��U214.568B2����޸��
Anime-Basede"https://anime-base.net
�
Aniyomi: Anime-Loads0eu.kanade.tachiyomi.animeextension.de.animeloads�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-de.animeloads-v14.34.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.de.animeloads.png"14(�U214.348B5���҈Anime-Loadsde"https://www.anime-loads.org
�
Aniyomi: Anime-Stream1eu.kanade.tachiyomi.animeextension.de.animestream�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-de.animestream-v14.3.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.de.animestream.png"14(ùU214.38B5����ة�Anime-Streamde"https://anime-stream.to
�
Aniyomi: AnimeToast0eu.kanade.tachiyomi.animeextension.de.animetoast�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-de.animetoast-v14.46.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.de.animetoast.png"14(�U214.468B5��٘�뽏!
AnimeToastde"https://www.animetoast.cc
�
Aniyomi: AniWorld.eu.kanade.tachiyomi.animeextension.de.aniworld�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-de.aniworld-v14.51.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.de.aniworld.png"14(�U214.518B-��������sAniWorldde"https://aniworld.to
�
Aniyomi: FilmPalast0eu.kanade.tachiyomi.animeextension.de.filmpalast�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-de.filmpalast-v14.34.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.de.filmpalast.png"14(�U214.348B1�÷ǵ���1
FilmPalastde"https://filmpalast.to
�
Aniyomi: Kinoking.eu.kanade.tachiyomi.animeextension.de.kinoking�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-de.kinoking-v14.43.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.de.kinoking.png"14(�U214.438B-��������Kinokingde"https://kinoking.cc
�
Aniyomi: Kool*eu.kanade.tachiyomi.animeextension.de.kool�
^https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-de.kool-v14.37.apkmhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.de.kool.png"14(�U214.378B)��ӽ����MKoolde"https://www.kool.to
�
Aniyomi: Moflix-Stream2eu.kanade.tachiyomi.animeextension.de.moflixstream�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-de.moflixstream-v14.38.apkuhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.de.moflixstream.png"14(�U214.388B8ʁ�����]Moflix-Streamde"https://moflix-stream.xyz
�
Aniyomi: Movie4k-eu.kanade.tachiyomi.animeextension.de.movie4k�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-de.movie4k-v14.26.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.de.movie4k.png"14(ڹU214.268B/ߺ������CMovie4kde"https://movie4k.stream
�
Aniyomi: Serienstream2eu.kanade.tachiyomi.animeextension.de.serienstream�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-de.serienstream-v14.41.apkuhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.de.serienstream.png"14(�U214.418B5�������PSerienstreamde"https://serienstream.to
�
Aniyomi: Anichi,eu.kanade.tachiyomi.animeextension.en.anichi�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.anichi-v16.15.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.anichi.png"16(��a216.158B)���ѐ�Anichien"https://anichi.to
�
Aniyomi: AniDB+eu.kanade.tachiyomi.animeextension.en.anidb�
_https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.anidb-v16.22.apknhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.anidb.png"16(��a216.228B3��Ϭ����1AniDBen"https://anilab2.amdapi.click
�
Aniyomi: AniHQ+eu.kanade.tachiyomi.animeextension.en.anihq�
^https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.anihq-v16.8.apknhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.anihq.png"16(��a216.88B'����뀝�4AniHQen"https://anihq.cc
�
Aniyomi: Anikage-eu.kanade.tachiyomi.animeextension.en.anikage�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.anikage-v14.15.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.anikage.png"14(ϹU214.158B+��ٲ����Anikageen"https://anikage.cc
�
Aniyomi: Anikoto-eu.kanade.tachiyomi.animeextension.en.anikoto�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.anikoto-v16.20.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.anikoto.png"16(��a216.208B-���ٰ̟�AAnikotoen"https://anikototv.bz
�
Aniyomi: AniKuro-eu.kanade.tachiyomi.animeextension.en.anikuro�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.anikuro-v16.12.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.anikuro.png"16(��a216.128B+��������IAniKuroen"https://anikuro.to
�
Aniyomi: AniList-eu.kanade.tachiyomi.animeextension.en.anilist�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.anilist-v16.16.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.anilist.png"16(��a216.168B+������ؐAniListen"https://anilist.co
�
Aniyomi: AnimeGG-eu.kanade.tachiyomi.animeextension.en.animegg�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.animegg-v14.3.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.animegg.png"14(ùU214.38B0��ݜͤ��AnimeGGen"https://www.animegg.org
�
Aniyomi: AnimeKhor/eu.kanade.tachiyomi.animeextension.en.animekhor�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.animekhor-v14.36.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.animekhor.png"14(�U214.368B0��뼭���	AnimeKhoren"https://animekhor.org
�
Aniyomi: Animenosub0eu.kanade.tachiyomi.animeextension.en.animenosub�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.animenosub-v14.39.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.animenosub.png"14(�U214.398B1��߾��إ]
Animenosuben"https://animenosub.to
�
Aniyomi: AnimePahe/eu.kanade.tachiyomi.animeextension.en.animepahe�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.animepahe-v16.63.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.animepahe.png"16(��a216.638B/���ڡ���	AnimePaheen"https://animepahe.pw
�
Aniyomi: AnimeParadise3eu.kanade.tachiyomi.animeextension.en.animeparadise�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.animeparadise-v16.8.apkvhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.animeparadise.png"16(��a216.88B<����ǐ��.AnimeParadiseen"https://www.animeparadise.moe
�
Aniyomi: AnimeSogo/eu.kanade.tachiyomi.animeextension.en.animesogo�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.animesogo-v16.15.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.animesogo.png"16(��a216.158B/��������u	AnimeSogoen"https://animesogo.to
�
Aniyomi: AnimeTake/eu.kanade.tachiyomi.animeextension.en.animetake�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.animetake-v16.31.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.animetake.png"16(��a216.318B/��鱑���g	AnimeTakeen"https://animetake.tv
�
Aniyomi: AnimeToki/eu.kanade.tachiyomi.animeextension.en.animetoki�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.animetoki-v16.3.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.animetoki.png"16(��a216.38B0��ˑ�㮩.	AnimeTokien"https://animetoki.com
�
Aniyomi: AniPM+eu.kanade.tachiyomi.animeextension.en.anipm�
_https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.anipm-v16.16.apknhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.anipm.png"16(��a216.168B%���靄��/AniPMen"https://ani.pm
�
Aniyomi: AniWave (Unoriginal)-eu.kanade.tachiyomi.animeextension.en.aniwave�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.aniwave-v16.21.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.aniwave.png"16(��a216.218B:��������<AniWave (Unoriginal)en"https://animewave.to
�
Aniyomi: AniWaves.ru.eu.kanade.tachiyomi.animeextension.en.aniwaves�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.aniwaves-v16.9.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.aniwaves.png"16(��a216.98B0ƞ������QAniWaves.ruen"https://aniwaves.tv
�
Aniyomi: AsiaFlix.eu.kanade.tachiyomi.animeextension.en.asiaflix�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.asiaflix-v14.40.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.asiaflix.png"14(�U214.408B.��©�׿�PAsiaFlixen"https://asiaflix.net
�
Aniyomi: AV1Encodes0eu.kanade.tachiyomi.animeextension.en.av1encodes�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.av1encodes-v16.9.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.av1encodes.png"16(��a216.98B2������Љ
AV1Encodesen"https://av1encodes.com
�
Aniyomi: BLZone,eu.kanade.tachiyomi.animeextension.en.blzone�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.blzone-v14.20.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.blzone.png"14(ԹU214.208B*➙��ʎ�BLZoneen"https://blzone.net
�
Aniyomi: Cinejoy-eu.kanade.tachiyomi.animeextension.en.cinejoy�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.cinejoy-v16.9.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.cinejoy.png"16(��a216.98B+�ѧ����0Cinejoyen"https://cinejoy.pk
�
Aniyomi: DonghuaStream3eu.kanade.tachiyomi.animeextension.en.donghuastream�
ghttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.donghuastream-v14.38.apkvhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.donghuastream.png"14(�U214.388B8�������ODonghuaStreamen"https://donghuastream.org
�
Aniyomi: Gotaku,eu.kanade.tachiyomi.animeextension.en.gotaku�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.gotaku-v16.19.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.gotaku.png"16(��a216.198B)Ơ����ÊHGotakuen"https://gotaku.to
�
Aniyomi: haho.moe-eu.kanade.tachiyomi.animeextension.en.hahomoe�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.hahomoe-v16.12.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.hahomoe.png"16(��a216.128B*��������3haho.moeen"https://haho.moe
�
Aniyomi: hanime.tv,eu.kanade.tachiyomi.animeextension.en.hanime�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.hanime-v16.30.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.hanime.png"16(��a216.308B,��ǚ����$	hanime.tven"https://hanime.tv
�
Aniyomi: HentaiHaven1eu.kanade.tachiyomi.animeextension.en.hentaihaven�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.hentaihaven-v16.15.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.hentaihaven.png"16(��a216.158B4��������HentaiHavenen"https://hentaihaven.xxx
�
Aniyomi: HentaiMama0eu.kanade.tachiyomi.animeextension.en.hentaimama�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.hentaimama-v16.14.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.hentaimama.png"16(��a216.148B1��ڇ»��o
HentaiMamaen"https://hentaimama.io
�
Aniyomi: HexaWatch/eu.kanade.tachiyomi.animeextension.en.hexawatch�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.hexawatch-v16.16.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.hexawatch.png"16(��a216.168B*�������y	HexaWatchen"https://hexa.su
�
Aniyomi: Hstream-eu.kanade.tachiyomi.animeextension.en.hstream�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.hstream-v16.14.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.hstream.png"16(��a216.148B,ᗫ��Ԑ�yHstreamen"https://hstream.moe
�
Aniyomi: Kayoanime/eu.kanade.tachiyomi.animeextension.en.kayoanime�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.kayoanime-v14.16.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.kayoanime.png"14(йU214.168B0�¤��Ǟ�	Kayoanimeen"https://kayoanime.com
�
Aniyomi: KickAssAnime2eu.kanade.tachiyomi.animeextension.en.kickassanime�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.kickassanime-v14.72.apkuhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.kickassanime.png"14(��U214.728B,���䖅��KickAssAnimeen"https://kaa.lt
�
Aniyomi: KimoiTV-eu.kanade.tachiyomi.animeextension.en.kimoitv�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.kimoitv-v14.2.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.kimoitv.png"14(¹U214.28B,��������XKimoiTVen"https://kimoitv.com
�
Aniyomi: KissKH,eu.kanade.tachiyomi.animeextension.en.kisskh�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.kisskh-v16.19.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.kisskh.png"16(��a216.198B*�������!KissKHen"https://kisskh.ovh
�
Aniyomi: AnimeKai (Unoriginal)-eu.kanade.tachiyomi.animeextension.en.kotokai�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.kotokai-v16.19.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.kotokai.png"16(��a216.198B<����މ�AnimeKai (Unoriginal)en"https://animekaitv.to
�
Aniyomi: LuciferDonghua4eu.kanade.tachiyomi.animeextension.en.luciferdonghua�
hhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.luciferdonghua-v14.33.apkwhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.luciferdonghua.png"14(�U214.338B9��������LuciferDonghuaen"https://luciferdonghua.in
�
Aniyomi: Mapple,eu.kanade.tachiyomi.animeextension.en.mapple�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.mapple-v16.15.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.mapple.png"16(��a216.158B*�ҕ�ѷ��=Mappleen"https://mapple.fun
�
Aniyomi: MKissa,eu.kanade.tachiyomi.animeextension.en.mkissa�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.mkissa-v16.86.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.mkissa.png"16(��a216.868B/��ظֹ��AMKissaen"https://mkissa.to/anime
�
Aniyomi: MoviesMod/eu.kanade.tachiyomi.animeextension.en.moviesmod�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.moviesmod-v16.10.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.moviesmod.png"16(��a216.108B2��������'
Movies Moden"https://moviesmod.zone
�
Aniyomi: My Running Man2eu.kanade.tachiyomi.animeextension.en.myrunningman�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.myrunningman-v14.16.apkuhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.myrunningman.png"14(йU214.168B<��ᓲ���XMy Running Manen"https://www.myrunningman.com
�
Aniyomi: 123Anime6eu.kanade.tachiyomi.animeextension.en.onetwothreeanime�
ihttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.onetwothreeanime-v14.9.apkyhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.onetwothreeanime.png"14(ɹU214.98B0Ӑ��123Animeen"https://123animehub.cc
�
Aniyomi: Oppai Stream1eu.kanade.tachiyomi.animeextension.en.oppaistream�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.oppaistream-v16.8.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.oppaistream.png"16(��a216.88B2��������Oppai Streamen"https://oppai.stream
�
Aniyomi: PinoyMoviePedia5eu.kanade.tachiyomi.animeextension.en.pinoymoviepedia�
ihttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.pinoymoviepedia-v14.14.apkxhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.pinoymoviepedia.png"14(ιU214.148B;����ʊ��vPinoyMoviePediaen"https://pinoymoviepedia.ru
�
Aniyomi: Re:ANIME-eu.kanade.tachiyomi.animeextension.en.reanime�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.reanime-v16.25.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.reanime.png"16(��a216.258B,�����ӥ�bRe:ANIMEen"https://reanime.cz
�
Aniyomi: Rule34Video1eu.kanade.tachiyomi.animeextension.en.rule34video�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.rule34video-v16.12.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.rule34video.png"16(��a216.128B4���뢅��Rule34Videoen"https://rule34video.com
�
Aniyomi: Senshi,eu.kanade.tachiyomi.animeextension.en.senshi�
_https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.senshi-v16.9.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.senshi.png"16(��a216.98B)������Senshien"https://senshi.to
�
Aniyomi: ShuttleTV/eu.kanade.tachiyomi.animeextension.en.shuttletv�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.shuttletv-v16.10.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.shuttletv.png"16(��a216.108B/����楏�
	ShuttleTVen"https://shuttletv.pk
�
Aniyomi: UHD Movies/eu.kanade.tachiyomi.animeextension.en.uhdmovies�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.uhdmovies-v14.24.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.uhdmovies.png"14(عU214.248B1�үɉ���
UHD Moviesen"https://uhdmovies.vip
�
Aniyomi: UniqueStream2eu.kanade.tachiyomi.animeextension.en.uniquestream�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.uniquestream-v16.11.apkuhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.uniquestream.png"16(��a216.118B<��������UniqueStreamen"https://anime.uniquestream.net
�
Aniyomi: WcoAnimeDub1eu.kanade.tachiyomi.animeextension.en.wcoanimedub�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.wcoanimedub-v14.16.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.wcoanimedub.png"14(йU214.168B7�٫�����wWcoAnimeDuben"https://www.wcoanimedub.tv
�
Aniyomi: WcoAnimeSub1eu.kanade.tachiyomi.animeextension.en.wcoanimesub�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.wcoanimesub-v14.16.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.wcoanimesub.png"14(йU214.168B7�����Ʋ�	WcoAnimeSuben"https://www.wcoanimesub.tv
�
Aniyomi: WcoForever0eu.kanade.tachiyomi.animeextension.en.wcoforever�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.wcoforever-v14.16.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.wcoforever.png"14(йU214.168B6�����ԅ�P
WcoForeveren"https://www.wcoforever.net
�
Aniyomi: Wcofun,eu.kanade.tachiyomi.animeextension.en.wcofun�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.wcofun-v14.30.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.wcofun.png"14(޹U214.308B.�Ϙ����Wcofunen"https://www.wcoflix.tv
�
Aniyomi: WCOStream/eu.kanade.tachiyomi.animeextension.en.wcostream�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.wcostream-v14.21.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.wcostream.png"14(չU214.218B3�������9	WCOStreamen"https://www.wcostream.tv
�
Aniyomi: WcoTv+eu.kanade.tachiyomi.animeextension.en.wcotv�
_https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.wcotv-v14.16.apknhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.wcotv.png"14(йU214.168B)������	WcoTven"https://www.wco.tv
�
Aniyomi: XAnime,eu.kanade.tachiyomi.animeextension.en.xanime�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-en.xanime-v16.15.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.en.xanime.png"16(��a216.158B)���Ҵ���-XAnimeen"https://xanime.me
�
Aniyomi: AnimeAv1.eu.kanade.tachiyomi.animeextension.es.animeav1�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.animeav1-v16.15.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.animeav1.png"16(��a216.158B.������AnimeAv1es"https://animeav1.com
�
Aniyomi: AnimeBum.eu.kanade.tachiyomi.animeextension.es.animebum�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.animebum-v14.33.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.animebum.png"14(�U214.338B2���Д��rAnimeBumes"https://www.animebum.net
�
Aniyomi: Animejl-eu.kanade.tachiyomi.animeextension.es.animejl�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.animejl-v14.32.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.animejl.png"14(�U214.328B1��壮ĵ�(Animejles"https://www.anime-jl.net
�
Aniyomi: AnimeLatinoHD3eu.kanade.tachiyomi.animeextension.es.animelatinohd�
ghttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.animelatinohd-v14.66.apkvhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.animelatinohd.png"14(��U214.668B<�݉���KAnimeLatinoHDes"https://www.animelatinohd.com
�
Aniyomi: AnimeMovil0eu.kanade.tachiyomi.animeextension.es.animemovil�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.animemovil-v14.61.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.animemovil.png"14(��U214.618B1ż������6
AnimeMoviles"https://animemeow.xyz
�
Aniyomi: Animenix.eu.kanade.tachiyomi.animeextension.es.animenix�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.animenix-v14.37.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.animenix.png"14(�U214.378B.���񶡞�Animenixes"https://animenix.com
�
Aniyomi: AnimeOnline.Ninja6eu.kanade.tachiyomi.animeextension.es.animeonlineninja�
jhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.animeonlineninja-v14.77.apkyhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.animeonlineninja.png"14(��U214.778B@�ݨ�܍��&AnimeOnline.Ninjaes"https://ww3.animeonline.ninja
�
Aniyomi: AnimeYT.es/eu.kanade.tachiyomi.animeextension.es.animeytes�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.animeytes-v14.41.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.animeytes.png"14(�U214.418B.��������A
AnimeYT.eses"https://animeyt.es
�
Aniyomi: AsiaLiveAction4eu.kanade.tachiyomi.animeextension.es.asialiveaction�
hhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.asialiveaction-v14.64.apkwhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.asialiveaction.png"14(��U214.648B:��������OAsiaLiveActiones"https://asialiveaction.com
�
Aniyomi: az-animex.eu.kanade.tachiyomi.animeextension.es.azanimex�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.azanimex-v14.4.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.azanimex.png"14(ĹU214.48B4��������k	az-animexes"https://www.az-animex.com
�
Aniyomi: BeatZ Anime0eu.kanade.tachiyomi.animeextension.es.beatzanime�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.beatzanime-v14.4.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.beatzanime.png"14(ĹU214.48B7����ݬ1BeatZ Animees"https://www.beatz-anime.net
�
Aniyomi: Cine24h-eu.kanade.tachiyomi.animeextension.es.cine24h�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.cine24h-v14.37.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.cine24h.png"14(�U214.378B/�������Cine24hes"https://cine24h.online
�
Aniyomi: CineCalidad1eu.kanade.tachiyomi.animeextension.es.cinecalidad�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.cinecalidad-v14.49.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.cinecalidad.png"14(�U214.498B7�Թ����	CineCalidades"https://www.cinecalidad.ec
�
Aniyomi: Cineplus1231eu.kanade.tachiyomi.animeextension.es.cineplus123�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.cineplus123-v14.33.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.cineplus123.png"14(�U214.338B4�������Cineplus123es"https://cineplus123.org
�
Aniyomi: Cuevana-eu.kanade.tachiyomi.animeextension.es.cuevana�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.cuevana-v14.82.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.cuevana.png"14(��U214.828B3ᢛ�����
Cuevana3Eues"https://wv3.cuevana3.eu
�
Aniyomi: Cuevana3Ch/eu.kanade.tachiyomi.animeextension.es.cuevanach�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.cuevanach-v14.75.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.cuevanach.png"14(��U214.758B3߽ʕ����o
Cuevana3Ches"https://ww1.cuevana3.ch
�
Aniyomi: DeTodoPeliculas5eu.kanade.tachiyomi.animeextension.es.detodopeliculas�
ihttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.detodopeliculas-v14.34.apkxhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.detodopeliculas.png"14(�U214.348B<�Ȩ�����EDeTodo Peliculases"https://detodopeliculas.nu
�
Aniyomi: Doramasflix1eu.kanade.tachiyomi.animeextension.es.doramasflix�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.doramasflix-v14.65.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.doramasflix.png"14(��U214.658B3�������Doramasflixes"https://doramasflix.in
�
Aniyomi: Doramasyt/eu.kanade.tachiyomi.animeextension.es.doramasyt�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.doramasyt-v14.52.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.doramasyt.png"14(��U214.528B4�Ƭ���ڥ	Doramasytes"https://www.doramasyt.com
�
Aniyomi: EnNovelas (Dead)/eu.kanade.tachiyomi.animeextension.es.ennovelas�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.ennovelas-v14.29.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.ennovelas.png"14(ݹU214.298B5��������\	EnNovelases"https://l.ennovelas-tv.com
�
Aniyomi: EstrenosDoramas5eu.kanade.tachiyomi.animeextension.es.estrenosdoramas�
ihttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.estrenosdoramas-v14.29.apkxhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.estrenosdoramas.png"14(ݹU214.298B;���㿐��EstrenosDoramases"https://estrenosdoramas.es
�
Aniyomi: FanPelis.eu.kanade.tachiyomi.animeextension.es.fanpelis�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.fanpelis-v14.32.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.fanpelis.png"14(�U214.328B-��������FanPelises"https://fanpelis.la
�
Aniyomi: FlixLatam/eu.kanade.tachiyomi.animeextension.es.flixlatam�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.flixlatam-v14.41.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.flixlatam.png"14(�U214.418B0�ᩖ�ǧ!	FlixLatames"https://flixlatam.com
�
Aniyomi: Gnula+eu.kanade.tachiyomi.animeextension.es.gnula�
_https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.gnula-v14.64.apknhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.gnula.png"14(��U214.648B)뒗�����_Gnulaes"https://gnula.life
�
Aniyomi: Hackstore/eu.kanade.tachiyomi.animeextension.es.hackstore�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.hackstore-v14.53.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.hackstore.png"14(��U214.538B3�Ղ�����	Hackstorees"https://www.hackstore.fo
�
Aniyomi: Hentaijk.eu.kanade.tachiyomi.animeextension.es.hentaijk�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.hentaijk-v14.27.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.hentaijk.png"14(۹U214.278B.��������@Hentaijkes"https://hentaijk.com
�
Aniyomi: Hentaila.eu.kanade.tachiyomi.animeextension.es.hentaila�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.hentaila-v14.56.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.hentaila.png"14(��U214.568B.������¼YHentailaes"https://hentaila.com
�
Aniyomi: HentaiTk.eu.kanade.tachiyomi.animeextension.es.hentaitk�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.hentaitk-v14.37.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.hentaitk.png"14(�U214.378B.�͞�����kHentaiTkes"https://hentaitk.net
�
Aniyomi: HomeCine.eu.kanade.tachiyomi.animeextension.es.homecine�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.homecine-v14.31.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.homecine.png"14(߹U214.318B-�����AHomeCinees"https://homecine.cc
�
Aniyomi: Jkanime-eu.kanade.tachiyomi.animeextension.es.jkanime�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.jkanime-v14.63.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.jkanime.png"14(��U214.638B,��Έ�ݞ�SJkanimees"https://jkanime.net
�
Aniyomi: Jkhentai.eu.kanade.tachiyomi.animeextension.es.jkhentai�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.jkhentai-v14.14.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.jkhentai.png"14(ιU214.148B2�������QJkhentaies"https://www.jkhentai.net
�
Aniyomi: Katanime.eu.kanade.tachiyomi.animeextension.es.katanime�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.katanime-v14.35.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.katanime.png"14(�U214.358B.��ˍ����#Katanimees"https://katanime.net
�
Aniyomi: LACartoons0eu.kanade.tachiyomi.animeextension.es.lacartoons�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.lacartoons-v14.35.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.lacartoons.png"14(�U214.358B6�ν��͞9
LACartoonses"https://www.lacartoons.com
�
Aniyomi: LaMovie-eu.kanade.tachiyomi.animeextension.es.lamovie�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.lamovie-v14.38.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.lamovie.png"14(�U214.388B)��µ��ʚKLaMoviees"https://la.movie
�
Aniyomi: Latanime.eu.kanade.tachiyomi.animeextension.es.latanime�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.latanime-v14.56.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.latanime.png"14(��U214.568B.��Ӡ����dLatanimees"https://latanime.org
�
Aniyomi: LegionAnime1eu.kanade.tachiyomi.animeextension.es.legionanime�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.legionanime-v14.61.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.legionanime.png"14(��U214.618B9��✙�ŇLegionAnimees"https://legionanime.club/api
�
Aniyomi: LocoPelis/eu.kanade.tachiyomi.animeextension.es.locopelis�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.locopelis-v14.48.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.locopelis.png"14(�U214.488B4�͇����j	LocoPelises"https://www.locopelis.com
�
Aniyomi: MetroSeries1eu.kanade.tachiyomi.animeextension.es.metroseries�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.metroseries-v14.44.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.metroseries.png"14(�U214.448B9ܨܼ�ζ�MetroSerieses"https://www3.seriesmetro.net
�
Aniyomi: MhdFlix-eu.kanade.tachiyomi.animeextension.es.mhdflix�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.mhdflix-v14.36.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.mhdflix.png"14(�U214.368B0��Ƙɞ��BMhdFlixes"https://ww1.mhdflix.com
�
Aniyomi: MonosChinos1eu.kanade.tachiyomi.animeextension.es.monoschinos�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.monoschinos-v14.68.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.monoschinos.png"14(��U214.688B3�͕�ߺ��`MonosChinoses"https://monoschinos.st
�
Aniyomi: MundoDonghua2eu.kanade.tachiyomi.animeextension.es.mundodonghua�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.mundodonghua-v14.56.apkuhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.mundodonghua.png"14(��U214.568B:������<MundoDonghuaes"https://www.mundodonghua.com
�
Aniyomi: Pandrama.eu.kanade.tachiyomi.animeextension.es.pandrama�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.pandrama-v14.18.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.pandrama.png"14(ҹU214.188B.�Հ�򱖇sPandramaes"https://pandrama.com
�
Aniyomi: PelisForte0eu.kanade.tachiyomi.animeextension.es.pelisforte�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.pelisforte-v14.65.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.pelisforte.png"14(��U214.658B6����Θ�=
PelisFortees"https://www2.pelisforte.se
�
Aniyomi: PelisPlusHD1eu.kanade.tachiyomi.animeextension.es.pelisplushd�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.pelisplushd-v14.108.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.pelisplushd.png"14(��U214.1088B3�ش�ׯ��PelisPlusHDes"https://pelisplushd.bz
�
Aniyomi: PelisPlusPh1eu.kanade.tachiyomi.animeextension.es.pelisplusph�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.pelisplusph-v14.108.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.pelisplusph.png"14(��U214.1088B7�������DPelisPlusPhes"https://www.pelisplushd.la
�
Aniyomi: PelisPlusTo1eu.kanade.tachiyomi.animeextension.es.pelisplusto�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.pelisplusto-v14.108.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.pelisplusto.png"14(��U214.1088B0궮˚���PelisPlusToes"https://tioplus.app
�
Aniyomi: Samato5eu.kanade.tachiyomi.animeextension.es.samatodenvideos�
hhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.samatodenvideos-v14.2.apkxhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.samatodenvideos.png"14(¹U214.28BDٌ��讙�}Samato's Den: Videoses"https://samatoden.blogspot.com
�
Aniyomi: SeriesKao/eu.kanade.tachiyomi.animeextension.es.serieskao�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.serieskao-v14.37.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.serieskao.png"14(�U214.378B0̟������	SeriesKaoes"https://serieskao.top
�
Aniyomi: SoloLatino0eu.kanade.tachiyomi.animeextension.es.sololatino�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.sololatino-v14.41.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.sololatino.png"14(�U214.418B2�����Ϫ�%
SoloLatinoes"https://sololatino.net
�
Aniyomi: TioanimeH/eu.kanade.tachiyomi.animeextension.es.tioanimeh�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.tioanimeh-v14.46.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.tioanimeh.png"14(�U214.468B.�֝��Ҁ�+TioAnimees"https://tioanime.comB0���빿��
	TioHentaies"https://tiohentai.com
�
Aniyomi: Tiodonghua.com0eu.kanade.tachiyomi.animeextension.es.tiodonghua�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.tiodonghua-v14.34.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.tiodonghua.png"14(�U214.348B<��������^Tiodonghua.comes"https://anime.tiodonghua.com
�
Aniyomi: VeoHentai/eu.kanade.tachiyomi.animeextension.es.veohentai�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.veohentai-v14.2.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.veohentai.png"14(¹U214.28B0ѝ������	VeoHentaies"https://veohentai.com
�
Aniyomi: VerAni.me.eu.kanade.tachiyomi.animeextension.es.veranime�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.veranime-v14.15.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.veranime.png"14(ϹU214.158B,�����"	VerAni.mees"https://verani.me
�
Aniyomi: VerAnimes/eu.kanade.tachiyomi.animeextension.es.veranimes�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.veranimes-v14.34.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.veranimes.png"14(�U214.348B4˄�����V	VerAnimeses"https://wwv.veranimes.net
�
Aniyomi: VerPelisTop1eu.kanade.tachiyomi.animeextension.es.verpelistop�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.verpelistop-v14.25.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.verpelistop.png"14(ٹU214.258B6�����qVerPelisTopes"https://www1.verpelis.top
�
Aniyomi: VerSeriesOnline5eu.kanade.tachiyomi.animeextension.es.verseriesonline�
ihttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.verseriesonline-v14.31.apkxhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.verseriesonline.png"14(߹U214.318B@���䠛��oVerSeriesOnlinees"https://www.verseriesonline.net
�
Aniyomi: zeroanime/eu.kanade.tachiyomi.animeextension.es.zeroanime�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.zeroanime-v14.25.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.zeroanime.png"14(ٹU214.258B5��������	zeroanimees"https://www4.zeroanime.xyz
�
Aniyomi: Zonaleros/eu.kanade.tachiyomi.animeextension.es.zonaleros�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-es.zonaleros-v14.31.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.es.zonaleros.png"14(߹U214.318B5�������g	Zonaleroses"https://www.zona-leros.com
�
Aniyomi: Anime-Sama/eu.kanade.tachiyomi.animeextension.fr.animesama�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-fr.animesama-v16.43.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.fr.animesama.png"16(��a216.438B1􀜁����U
Anime-Samafr"https://anime-sama.to
�
Aniyomi: AnimeVostFr1eu.kanade.tachiyomi.animeextension.fr.animevostfr�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-fr.animevostfr-v14.3.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.fr.animevostfr.png"14(ùU214.38B3���҆���MAnimeVostFrfr"https://animevostfr.tv
�
Aniyomi: EmpireStreaming5eu.kanade.tachiyomi.animeextension.fr.empirestreaming�
ihttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-fr.empirestreaming-v14.39.apkxhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.fr.empirestreaming.png"14(�U214.398B:���ۮ�EmpireStreamingfr"https://empire-stream.net
�
Aniyomi: FRAnime-eu.kanade.tachiyomi.animeextension.fr.franime�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-fr.franime-v16.39.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.fr.franime.png"16(��a216.398B+�����ۡ�*FRAnimefr"https://franime.fr
�
Aniyomi: French Anime1eu.kanade.tachiyomi.animeextension.fr.frenchanime�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-fr.frenchanime-v14.44.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.fr.frenchanime.png"14(�U214.448B6Ʌ������pFrench Animefr"https://french-anime.com
�
Aniyomi: HDS)eu.kanade.tachiyomi.animeextension.fr.hds�
]https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-fr.hds-v14.30.apklhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.fr.hds.png"14(޹U214.308B*�߯���,HDSfr"https://on1.hds.quest
�
Aniyomi: JetAnime.eu.kanade.tachiyomi.animeextension.fr.jetanime�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-fr.jetanime-v14.31.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.fr.jetanime.png"14(߹U214.318B3�纐����{JetAnimefr"https://ssl.jetanimes.com
�
Aniyomi: MyKdrama.eu.kanade.tachiyomi.animeextension.fr.mykdrama�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-fr.mykdrama-v14.30.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.fr.mykdrama.png"14(޹U214.308B-ѝ�����jMyKdramafr"https://mykdrama.co
�
Aniyomi: OtakuFR-eu.kanade.tachiyomi.animeextension.fr.otakufr�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-fr.otakufr-v14.51.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.fr.otakufr.png"14(�U214.518B+�Դ����OtakuFRfr"https://otakufr.cc
�
Aniyomi: Voiranime/eu.kanade.tachiyomi.animeextension.fr.voiranime�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-fr.voiranime-v16.12.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.fr.voiranime.png"16(��a216.128B/���֮���J	Voiranimefr"https://voiranime.cx
�
Aniyomi: VoirCartoon1eu.kanade.tachiyomi.animeextension.fr.voircartoon�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-fr.voircartoon-v14.27.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.fr.voircartoon.png"14(۹U214.278B4�������[VoirCartoonfr"https://voircartoon.com
�
Aniyomi: Vostfree.eu.kanade.tachiyomi.animeextension.fr.vostfree�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-fr.vostfree-v14.52.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.fr.vostfree.png"14(��U214.528B-�ᯯӥwVostfreefr"https://vostfree.ws
�
Aniyomi: Wiflix,eu.kanade.tachiyomi.animeextension.fr.wiflix�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-fr.wiflix-v14.41.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.fr.wiflix.png"14(�U214.418B+���ߝ��cWiflixfr"https://flemmix.run
�
Aniyomi: YoMovies.eu.kanade.tachiyomi.animeextension.hi.yomovies�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-hi.yomovies-v14.43.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.hi.yomovies.png"14(�U214.438B2��ݳ����"YoMovieshi"https://yomovies.academy
�
Aniyomi: AnimeIndo/eu.kanade.tachiyomi.animeextension.id.animeindo�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-id.animeindo-v14.39.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.id.animeindo.png"14(�U214.398B1�ܫ���ك	AnimeIndoid"https://animeindo.skin
�
Aniyomi: Kuramanime0eu.kanade.tachiyomi.animeextension.id.kuramanime�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-id.kuramanime-v14.35.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.id.kuramanime.png"14(�U214.358B5Ν߼����@
Kuramanimeid"https://v8.kuramanime.tel
�
Aniyomi: Kuronime.eu.kanade.tachiyomi.animeextension.id.kuronime�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-id.kuronime-v14.17.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.id.kuronime.png"14(ѹU214.178B2��ꢯ���Kuronimeid"https://tv1.kuronime.vip
�
Aniyomi: MiniOppai/eu.kanade.tachiyomi.animeextension.id.minioppai�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-id.minioppai-v14.22.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.id.minioppai.png"14(ֹU214.228B0�������/	MiniOppaiid"https://minioppai.org
�
Aniyomi: NeoNime-eu.kanade.tachiyomi.animeextension.id.neonime�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-id.neonime-v14.35.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.id.neonime.png"14(�U214.358B,�ۺ���\NeoNimeid"https://neonime.ink
�
Aniyomi: NimeGami.eu.kanade.tachiyomi.animeextension.id.nimegami�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-id.nimegami-v14.9.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.id.nimegami.png"14(ɹU214.98B-�蟧���6NimeGamiid"https://nimegami.id
�
Aniyomi: Oploverz.eu.kanade.tachiyomi.animeextension.id.oploverz�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-id.oploverz-v16.35.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.id.oploverz.png"16(��a216.358B/�������#Oploverzid"https://oploverz.site
�
Aniyomi: OtakuDesu/eu.kanade.tachiyomi.animeextension.id.otakudesu�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-id.otakudesu-v14.51.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.id.otakudesu.png"14(�U214.518B1�����ڛ�/	OtakuDesuid"https://otakudesu.blog
�
Aniyomi: Samehadaku0eu.kanade.tachiyomi.animeextension.id.samehadaku�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-id.samehadaku-v14.13.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.id.samehadaku.png"14(͹U214.138B5�ל����g
Samehadakuid"https://v2.samehadaku.how
�
Aniyomi: Anime Saturn1eu.kanade.tachiyomi.animeextension.it.animesaturn�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-it.animesaturn-v14.24.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.it.animesaturn.png"14(عU214.248B4��廧���AnimeSaturnit"https://animesaturn.net
�
Aniyomi: AnimeUnity0eu.kanade.tachiyomi.animeextension.it.animeunity�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-it.animeunity-v14.10.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.it.animeunity.png"14(ʹU214.108B5֏��ݲ��k
AnimeUnityit"https://www.animeunity.so
�
Aniyomi: ANIMEWORLD.tv0eu.kanade.tachiyomi.animeextension.it.animeworld�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-it.animeworld-v16.70.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.it.animeworld.png"16(��a216.708B8ة�٣���[ANIMEWORLD.tvit"https://www.animeworld.ac
�
Aniyomi: AniPlay-eu.kanade.tachiyomi.animeextension.it.aniplay�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-it.aniplay-v14.29.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.it.aniplay.png"14(ݹU214.298B+��Ʀ����~AniPlayit"https://aniplay.co
�
Aniyomi: Hentai Saturn2eu.kanade.tachiyomi.animeextension.it.hentaisaturn�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-it.hentaisaturn-v14.6.apkuhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.it.hentaisaturn.png"14(ƹU214.68B:�������PHentaiSaturnit"https://www.hentaisaturn.com
�
Aniyomi: Toonitalia0eu.kanade.tachiyomi.animeextension.it.toonitalia�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-it.toonitalia-v14.45.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.it.toonitalia.png"14(��U214.458B4�����{
Toonitaliait"https://toonitalia.green
�
Aniyomi: VVVVID,eu.kanade.tachiyomi.animeextension.it.vvvvid�
_https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-it.vvvvid-v14.2.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.it.vvvvid.png"14(¹U214.28B-�������sVVVVIDit"https://www.vvvvid.it
�
Aniyomi: Aniweek-eu.kanade.tachiyomi.animeextension.ko.aniweek�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ko.aniweek-v14.25.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ko.aniweek.png"14(ٹU214.258B,��֡��?Aniweekko"https://aniweek.com
�
Aniyomi: desu-online0eu.kanade.tachiyomi.animeextension.pl.desuonline�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pl.desuonline-v14.28.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pl.desuonline.png"14(ܹU214.288B3�������Sdesu-onlinepl"https://desu-online.pl
�
Aniyomi: Docchi,eu.kanade.tachiyomi.animeextension.pl.docchi�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pl.docchi-v16.27.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pl.docchi.png"16(��a216.278B)�ƤԨ���Docchipl"https://docchi.pl
�
Aniyomi: OgladajAnime2eu.kanade.tachiyomi.animeextension.pl.ogladajanime�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pl.ogladajanime-v14.7.apkuhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pl.ogladajanime.png"14(ǹU214.78B5���޳���OgladajAnimepl"https://ogladajanime.pl
�
Aniyomi: Anikatsu.eu.kanade.tachiyomi.animeextension.pt.anikatsu�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.anikatsu-v14.6.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.anikatsu.png"14(ƹU214.68B1����ӆ��\Anikatsupt-BR"https://anikatsu.top
�
Aniyomi: Anikyuu-eu.kanade.tachiyomi.animeextension.pt.anikyuu�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.anikyuu-v14.27.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.anikyuu.png"14(۹U214.278B4���﫻��<Anikyuupt-BR"https://j-s-an.github.io
�
Aniyomi: Anime Fire/eu.kanade.tachiyomi.animeextension.pt.animefire�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animefire-v16.16.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animefire.png"16(��a216.168B4ݡ��(
Anime Firept-BR"https://animefire.one
�
Aniyomi: AnimeIto.eu.kanade.tachiyomi.animeextension.pt.animeito�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animeito-v16.29.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animeito.png"16(��a216.298B4��������LAnimeitopt-BR"https://animesonline.io
�
Aniyomi: AnimePlay/eu.kanade.tachiyomi.animeextension.pt.animeplay�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animeplay-v14.14.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animeplay.png"14(ιU214.148B6����͔7
Anime Playpt-BR"https://animeplay.cloud
�
Aniyomi: AnimePlayer1eu.kanade.tachiyomi.animeextension.pt.animeplayer�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animeplayer-v14.11.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animeplayer.png"14(˹U214.118B:뒊����YAnimePlayerpt-BR"https://animeplayer.com.br
�
Aniyomi: AnimeQ,eu.kanade.tachiyomi.animeextension.pt.animeq�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animeq-v14.16.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animeq.png"14(йU214.168B/�ׅ�����2AnimeQpt-BR"https://animeq.cloud
�
Aniyomi: Animes Digital3eu.kanade.tachiyomi.animeextension.pt.animesdigital�
ghttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animesdigital-v16.13.apkvhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animesdigital.png"16(��a216.138B<���᏾��CAnimes Digitalpt-BR"https://animesdigital.org
�
Aniyomi: AnimesDrive1eu.kanade.tachiyomi.animeextension.pt.animesdrive�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animesdrive-v14.21.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animesdrive.png"14(չU214.218B;��٭����UAnimes Drivept-BR"https://animesdrive.online
�
Aniyomi: TopAnimes2eu.kanade.tachiyomi.animeextension.pt.animesgratis�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animesgratis-v14.54.apkuhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animesgratis.png"14(��U214.548B3���҉��)	TopAnimespt-BR"https://topanimes.net
�
Aniyomi: Animes HD.eu.kanade.tachiyomi.animeextension.pt.animeshd�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animeshd-v14.4.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animeshd.png"14(ĹU214.48B1��������	Animes HDpt-BR"https://animeshd.to
�
Aniyomi: AnimesOnline Blue6eu.kanade.tachiyomi.animeextension.pt.animesonlineblue�
ihttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animesonlineblue-v14.4.apkyhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animesonlineblue.png"14(ĹU214.48B?ʢ���cAnimesOnline Bluept-BR"https://animesonline.blue
�
Aniyomi: Animes Online CC4eu.kanade.tachiyomi.animeextension.pt.animesonlinecc�
ghttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animesonlinecc-v14.8.apkwhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animesonlinecc.png"14(ȹU214.88B>����׋��fAnimes Online CCpt-BR"https://animesonlinecc.to
�
Aniyomi: AnimesOnlineCloud7eu.kanade.tachiyomi.animeextension.pt.animesonlinecloud�
khttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animesonlinecloud-v14.16.apkzhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animesonlinecloud.png"14(йU214.168BBٷ������`Animes Online Cloudpt-BR"https://animesonline.cloud
�
Aniyomi: AnimesOnlines Net6eu.kanade.tachiyomi.animeextension.pt.animesonlinesnet�
ihttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animesonlinesnet-v14.8.apkyhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animesonlinesnet.png"14(ȹU214.88B?�ɪ���Ɗ)AnimesOnlines Netpt-BR"https://animesonlines.net
�
Aniyomi: AnimesROLL0eu.kanade.tachiyomi.animeextension.pt.animesroll�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animesroll-v14.21.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animesroll.png"14(չU214.218B0�������
AnimesROLLpt-BR"https://anroll.io
�
Aniyomi: Animes Tokyo1eu.kanade.tachiyomi.animeextension.pt.animestokyo�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animestokyo-v14.8.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animestokyo.png"14(ȹU214.88B5������ô}Animes Tokyopt-BR"https://animes.tokyo
�
Aniyomi: AnimeXHD.eu.kanade.tachiyomi.animeextension.pt.animexhd�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animexhd-v14.8.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animexhd.png"14(ȹU214.88B1��������FAnimeXHDpt-BR"https://animexhd.xyz
�
Aniyomi: Animy+eu.kanade.tachiyomi.animeextension.pt.animy�
^https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.animy-v16.4.apknhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.animy.png"16(��a216.48B+����ﶤAAnimypt-BR"https://animy.net
�
Aniyomi: Anitube-eu.kanade.tachiyomi.animeextension.pt.anitube�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.anitube-v14.31.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.anitube.png"14(߹U214.318B3�������Anitubept-BR"https://www.anitube.vip
�
Aniyomi: Aniture PT-eu.kanade.tachiyomi.animeextension.pt.aniture�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.aniture-v14.1.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.aniture.png"14(��U214.18B8���ˠ��i
Aniture PTpt-BR"https://aniture-pt.com.br
�
Aniyomi: Berry Animes1eu.kanade.tachiyomi.animeextension.pt.berryanimes�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.berryanimes-v14.10.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.berryanimes.png"14(ʹU214.108B8��������^Berry Animespt-BR"https://berryanimes.com
�
Aniyomi: BetterAnimeIo3eu.kanade.tachiyomi.animeextension.pt.betteranimeio�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.betteranimeio-v14.6.apkvhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.betteranimeio.png"14(ƹU214.68B8�������!BetterAnimeIopt-BR"https://betteranime.io
�
Aniyomi: CineVEO-eu.kanade.tachiyomi.animeextension.pt.cineveo�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.cineveo-v14.4.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.cineveo.png"14(ĹU214.48B1�����壅,CineVEOpt-BR"https://cineveo20.lat
�
Aniyomi: DarkMahou/eu.kanade.tachiyomi.animeextension.pt.darkmahou�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.darkmahou-v14.30.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.darkmahou.png"14(޹U214.308B;����ْ�jDarkMahou (Torrent)pt-BR"https://darkmahou.io
�
Aniyomi: DattebayoBR1eu.kanade.tachiyomi.animeextension.pt.dattebayobr�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.dattebayobr-v14.4.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.dattebayobr.png"14(ĹU214.48B=�Φ�����Dattebayo BRpt-BR"https://www.dattebayo-br.com
�
Aniyomi: Donghua no Sekai4eu.kanade.tachiyomi.animeextension.pt.donghuanosekai�
ghttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.donghuanosekai-v14.4.apkwhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.donghuanosekai.png"14(ĹU214.48B?Ʒ������Donghua no Sekaipt-BR"https://donghuanosekai.com
�
Aniyomi: Doramogo.eu.kanade.tachiyomi.animeextension.pt.doramogo�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.doramogo-v14.22.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.doramogo.png"14(ֹU214.228B1�������Doramogopt-BR"https://doramogo.com
�
Aniyomi: Fun Anime TV0eu.kanade.tachiyomi.animeextension.pt.funanimetv�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.funanimetv-v14.4.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.funanimetv.png"14(ĹU214.48B8��������mFun Anime TVpt-BR"https://funanimetv.cyou
�
Aniyomi: Goyabu,eu.kanade.tachiyomi.animeextension.pt.goyabu�
_https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.goyabu-v14.8.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.goyabu.png"14(ȹU214.88B,��������Goyabupt-BR"https://goyabu.io
�
Aniyomi: Meus Animes0eu.kanade.tachiyomi.animeextension.pt.meusanimes�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.meusanimes-v14.7.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.meusanimes.png"14(ǹU214.78B7��ӻ����tMeus Animespt-BR"https://meusanimes.blog
�
Aniyomi: Muito Hentai1eu.kanade.tachiyomi.animeextension.pt.muitohentai�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.muitohentai-v14.4.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.muitohentai.png"14(ĹU214.48B<�������Muito Hentaipt-BR"https://www.muitohentai.com
�
Aniyomi: New Reiwa.eu.kanade.tachiyomi.animeextension.pt.newreiwa�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.newreiwa-v14.4.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.newreiwa.png"14(ĹU214.48B2��Ц��Ę_	New Reiwapt-BR"https://newreiwa.com
�
Aniyomi: Pi Fansubs/eu.kanade.tachiyomi.animeextension.pt.pifansubs�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.pifansubs-v14.41.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.pifansubs.png"14(�U214.418B5��������"
Pi Fansubspt-BR"https://pifansubs.club
�
Aniyomi: Pobreflix Irish4eu.kanade.tachiyomi.animeextension.pt.pobreflixirish�
ghttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.pobreflixirish-v14.6.apkwhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.pobreflixirish.png"14(ƹU214.68B?�͘����3Pobreflix Irishpt-BR"https://www.pobreflix.irish
�
Aniyomi: Rede Canais0eu.kanade.tachiyomi.animeextension.pt.redecanais�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.redecanais-v14.4.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.redecanais.png"14(ĹU214.48B7�������oRede Canaispt-BR"https://redecanais.plus
�
Aniyomi: RedeToons/eu.kanade.tachiyomi.animeextension.pt.redetoons�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.redetoons-v14.5.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.redetoons.png"14(ŹU214.58B2Ḿ���ϯP	RedeToonspt-BR"https://redetoons.my
�
Aniyomi: SeriesFlixNow3eu.kanade.tachiyomi.animeextension.pt.seriesflixnow�
fhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.seriesflixnow-v14.9.apkvhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.seriesflixnow.png"14(ɹU214.98B?�ժ���٥SSeriesFlixNowpt-BR"https://www.seriesflixnet.com
�
Aniyomi: SmartAnimes1eu.kanade.tachiyomi.animeextension.pt.smartanimes�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.smartanimes-v14.10.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.smartanimes.png"14(ʹU214.108B7����嫰cSmartAnimespt-BR"https://smartanimes.net
�
Aniyomi: Startflix/eu.kanade.tachiyomi.animeextension.pt.startflix�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.startflix-v14.8.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.startflix.png"14(ȹU214.88B7�����͈�I	Startflixpt-BR"https://www.startflix.biz
�
Aniyomi: Streamberry1eu.kanade.tachiyomi.animeextension.pt.streamberry�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.streamberry-v14.8.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.streamberry.png"14(ȹU214.88B:낢ю���Streamberrypt-BR"https://streamberry.com.br
�
Aniyomi: SushiAnimes1eu.kanade.tachiyomi.animeextension.pt.sushianimes�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.sushianimes-v14.4.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.sushianimes.png"14(ĹU214.48B;��ڟЫ��*Sushi Animespt-BR"https://sushianimes.com.br
�
Aniyomi: Tomato,eu.kanade.tachiyomi.animeextension.pt.tomato�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.tomato-v14.18.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.tomato.png"14(ҹU214.188B<�젏�Г�-Tomatopt-BR"!https://prod-api.tomatoanimes.com
�
Aniyomi: YUMEFREE.eu.kanade.tachiyomi.animeextension.pt.yumefree�
ahttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-pt.yumefree-v14.8.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.pt.yumefree.png"14(ȹU214.88B4��������9YUMEFREEpt-BR"https://yumefree.online
�
Aniyomi: AnimeGO.studio-eu.kanade.tachiyomi.animeextension.ru.animego�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ru.animego-v16.7.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ru.animego.png"16(��a216.78B6�������AnimeGO.studioru"https://animego.studio
�
Aniyomi: Animelib.eu.kanade.tachiyomi.animeextension.ru.animelib�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ru.animelib-v14.28.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ru.animelib.png"14(ܹU214.288B1���㸋��Animelibru"https://animelib.org/ru
�
Aniyomi: Animevost/eu.kanade.tachiyomi.animeextension.ru.animevost�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ru.animevost-v14.11.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ru.animevost.png"14(˹U214.118B0ڨ������\	Animevostru"https://animevost.orgB5������̊_Animevost Mirrorru"https://v13.vost.pw
�
Aniyomi: Jutsu TV+eu.kanade.tachiyomi.animeextension.ru.jutsu�
^https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ru.jutsu-v16.8.apknhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ru.jutsu.png"16(��a216.88B*��􌤳��>Jutsu TVru"https://jutsu.tv
�
Aniyomi: HDRezka+eu.kanade.tachiyomi.animeextension.ru.rezka�
^https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ru.rezka-v16.6.apknhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ru.rezka.png"16(��a216.68B+�߁�����'HDRezkaru"https://hdrezka.me
�
Aniyomi: YummyAnime0eu.kanade.tachiyomi.animeextension.ru.yummyanime�
dhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-ru.yummyanime-v16.11.apkshttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.ru.yummyanime.png"16(��a216.118B2��������T
YummyAnimeru"https://ru.yummyani.me
�
Aniyomi: AnimeBalkan1eu.kanade.tachiyomi.animeextension.sr.animebalkan�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-sr.animebalkan-v14.25.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.sr.animebalkan.png"14(ٹU214.258B4���䔽��AnimeBalkansr"https://animebalkan.org
�
Aniyomi: Anime Srbija1eu.kanade.tachiyomi.animeextension.sr.animesrbija�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-sr.animesrbija-v14.34.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.sr.animesrbija.png"14(�U214.348B9��հ����
Anime Srbijasr"https://www.animesrbija.com
�
Aniyomi: Animeler.eu.kanade.tachiyomi.animeextension.tr.animeler�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-tr.animeler-v14.47.apkqhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.tr.animeler.png"14(�U214.478B-��ҐԨ��[Animelertr"https://animeler.pw
�
Aniyomi: Anizm+eu.kanade.tachiyomi.animeextension.tr.anizm�
_https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-tr.anizm-v14.58.apknhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.tr.anizm.png"14(��U214.588B(���ގ���+Anizmtr"https://anizm.net
�
Aniyomi: AsyaAnimeleri3eu.kanade.tachiyomi.animeextension.tr.asyaanimeleri�
ghttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-tr.asyaanimeleri-v14.34.apkvhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.tr.asyaanimeleri.png"14(�U214.348B8�޽�ܿ�AsyaAnimeleritr"https://asyaanimeleri.top
�
Aniyomi: TRAnimeCI/eu.kanade.tachiyomi.animeextension.tr.tranimeci�
chttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-tr.tranimeci-v14.11.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.tr.tranimeci.png"14(˹U214.118B0ȶǚ͵��Q	TRAnimeCItr"https://tranimaci.com
�
Aniyomi: TR Anime Izle1eu.kanade.tachiyomi.animeextension.tr.tranimeizle�
ehttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-tr.tranimeizle-v14.48.apkthttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.tr.tranimeizle.png"14(�U214.488B9��臮�ݘ$TR Anime Izletr"https://www.tranimeizle.io
�
Aniyomi: UAKino,eu.kanade.tachiyomi.animeextension.uk.uakino�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-uk.uakino-v14.12.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.uk.uakino.png"14(̹U214.128B+ʷ��賫�UAKinouk"https://uakino.best
�
Aniyomi: UFDub+eu.kanade.tachiyomi.animeextension.uk.ufdub�
^https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-uk.ufdub-v14.2.apknhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.uk.ufdub.png"14(¹U214.28B.�έ�����8UFDubuk"https://ufdub.com/anime
�
Aniyomi: Anime1.me,eu.kanade.tachiyomi.animeextension.zh.anime1�
_https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-zh.anime1-v14.5.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.zh.anime1.png"14(ŹU214.58B1��Ϋ����p	Anime1.mezh-hant"https://anime1.me
�
Aniyomi: Cycity,eu.kanade.tachiyomi.animeextension.zh.cycity�
_https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-zh.cycity-v14.4.apkohttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.zh.cycity.png"14(ĹU214.48B7Ë��Ӝ��D次元城动漫zh"https://www.cycani.org
�
Aniyomi: Hanime1.me-eu.kanade.tachiyomi.animeextension.zh.hanime1�
`https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-zh.hanime1-v14.8.apkphttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.zh.hanime1.png"14(ȹU214.88B.��澧���'
Hanime1.mezh"https://hanime1.me
�
Aniyomi: iyf)eu.kanade.tachiyomi.animeextension.zh.iyf�
\https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-zh.iyf-v14.2.apklhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.zh.iyf.png"14(¹U214.28B-�������+	爱壹帆zh"https://www.iyf.tv
�
Aniyomi: Nivod+eu.kanade.tachiyomi.animeextension.zh.nivod�
^https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-zh.nivod-v14.2.apknhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.zh.nivod.png"14(¹U214.28B/؜������	泥视频zh"https://www.nivod.cc
�
Aniyomi: Xfani+eu.kanade.tachiyomi.animeextension.zh.xfani�
^https://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-zh.xfani-v14.9.apknhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.zh.xfani.png"14(ɹU214.98B8�������{稀饭动漫zh"https://anime.xifanacg.com
�
Aniyomi: Xiaoxintv/eu.kanade.tachiyomi.animeextension.zh.xiaoxintv�
bhttps://raw.githubusercontent.com/Awerkori/anime-extensoes/repo/apk/aniyomi-zh.xiaoxintv-v14.3.apkrhttps://cdn.jsdelivr.net/gh/Awerkori/anime-extensoes@repo/icon/eu.kanade.tachiyomi.animeextension.zh.xiaoxintv.png"14(ùU214.38B0�ڤ���m小宝影院zh"https://ibaotv.com